const rowsInput = document.getElementById('rowsInput');
const colsInput = document.getElementById('colsInput');
const createTableBtn = document.getElementById('createTableBtn');
const multiplicationTable = document.getElementById('multiplicationTable');
const modal = document.getElementById('modal');
const modalContent = document.getElementById('modalContent');
const closeModalBtn = document.getElementById('closeModalBtn');

function createTable() {
    const rows = parseInt(rowsInput.value);
    const cols = parseInt(colsInput.value);

    if (isNaN(rows) || isNaN(cols) || rows < 1 || rows > 20 || cols < 1 || cols > 20) {
        alert('Пожалуйста, введите числа от 1 до 20.');
        return;
    }

    multiplicationTable.innerHTML = '';

    const headerRow = document.createElement('tr');
    const topLeftHeader = document.createElement('th');
    topLeftHeader.textContent = '×';
    headerRow.appendChild(topLeftHeader);

    for (let j = 1; j <= cols; j++) {
        const headerCell = document.createElement('th');
        headerCell.textContent = j;
        headerRow.appendChild(headerCell);
    }
    multiplicationTable.appendChild(headerRow);

    for (let i = 1; i <= rows; i++) {
        const row = document.createElement('tr');
        const rowHeader = document.createElement('th');
        rowHeader.textContent = i;
        row.appendChild(rowHeader);

        for (let j = 1; j <= cols; j++) {
            const cell = document.createElement('td');
            const product = i * j;
            cell.textContent = product;
            cell.dataset.row = i;
            cell.dataset.col = j;

            cell.addEventListener('click', () => {
                modalContent.innerHTML = `
                    <p>Номер строки: <strong>${i}</strong></p>
                    <p>Номер столбца: <strong>${j}</strong></p>
                    <p>Результат умножения: <strong>${product}</strong></p>
                `;
                modal.style.display = 'block';
            });

            row.appendChild(cell);
        }

        multiplicationTable.appendChild(row);
    }
}

function closeModal() {
    modal.style.display = 'none';
}

createTableBtn.addEventListener('click', createTable);
closeModalBtn.addEventListener('click', closeModal);

modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.style.display === 'block') {
        closeModal();
    }
});

createTable();