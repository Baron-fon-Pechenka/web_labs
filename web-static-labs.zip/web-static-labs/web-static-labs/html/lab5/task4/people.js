const randomPeople = [
    { lastName: "Иванов", firstName: "Иван", age: 30, phone: "+7 (999) 111-11-11" },
    { lastName: "Петрова", firstName: "Мария", age: 25, phone: "+7 (999) 222-22-22" },
    { lastName: "Сидоров", firstName: "Алексей", age: 40, phone: "+7 (999) 333-33-33" },
    { lastName: "Козлова", firstName: "Ольга", age: 35, phone: "+7 (999) 444-44-44" },
    { lastName: "Волков", firstName: "Дмитрий", age: 28, phone: "+7 (999) 555-55-55" },
    { lastName: "Морозова", firstName: "Елена", age: 32, phone: "+7 (999) 666-66-66" },
    { lastName: "Новиков", firstName: "Максим", age: 27, phone: "+7 (999) 777-77-77" },
    { lastName: "Федорова", firstName: "Анна", age: 31, phone: "+7 (999) 888-88-88" },
    { lastName: "Михайлов", firstName: "Артём", age: 29, phone: "+7 (999) 999-99-99" },
    { lastName: "Васильева", firstName: "Екатерина", age: 33, phone: "+7 (999) 000-00-00" }
];