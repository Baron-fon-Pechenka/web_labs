const lastNameInput = document.getElementById('lastName');
const firstNameInput = document.getElementById('firstName');
const ageInput = document.getElementById('age');
const phoneInput = document.getElementById('phone');
const addContactBtn = document.getElementById('addContactBtn');
const randomContactBtn = document.getElementById('randomContactBtn');
const contactsTableBody = document.getElementById('contactsTableBody');

const filterLastNameInput = document.getElementById('filterLastName');
const filterFirstNameInput = document.getElementById('filterFirstName');
const filterAgeInput = document.getElementById('filterAge');
const filterPhoneInput = document.getElementById('filterPhone');
const filterBtn = document.getElementById('filterBtn');

let contacts = [];
let filteredContacts = [];

// --- НОВОЕ: Функция для нормализации номера телефона ---
function normalizePhoneNumber(phoneStr) {
    // Удаляем все нецифровые символы
    const cleaned = phoneStr.replace(/\D/g, '');
    // Если начинается с 7 или 8 и длина 11 -> заменяем на +7
    if ((cleaned.startsWith('7') || cleaned.startsWith('8')) && cleaned.length === 11) {
        return `+7${cleaned.substring(1)}`;
    }
    // Если начинается с 9 и длина 10 -> это номер без кода страны, добавляем +7
    if (cleaned.startsWith('9') && cleaned.length === 10) {
        return `+7${cleaned}`;
    }
    // Иначе возвращаем как есть (или можно добавить другие правила)
    // Для простоты, если не подходит под стандарт, возвращаем очищенный вариант с +
    if (cleaned.length > 0) {
        return `+${cleaned}`;
    }
    return cleaned; // пустая строка, если ничего не введено
}
// -------------------------------------------------------

function addContact(lastName, firstName, age, phone) {
    if (lastName && firstName) {
        // Преобразуем возраст в число перед сохранением
        const contact = {
            lastName,
            firstName,
            age: Number(age),
            // Нормализуем телефон при добавлении
            phone: normalizePhoneNumber(phone)
        };
        contacts.push(contact);
        renderTable(contacts);
    }
}

// Функция сортировки по возрасту (числовая)
function sortContactsByAge(contactList) {
    return [...contactList].sort((a, b) => {
        // Сравниваем числовые значения возраста
        return a.age - b.age;
    });
}

function renderTable(contactList) {
    contactsTableBody.innerHTML = '';

    // Сортируем контакты по возрасту
    const sortedContacts = sortContactsByAge(contactList);

    sortedContacts.forEach(contact => {
        const row = document.createElement('tr');
        // Отображаем телефон в нормализованном виде
        row.innerHTML = `
            <td>${contact.lastName}</td>
            <td>${contact.firstName}</td>
            <td>${contact.age}</td>
            <td>${contact.phone}</td>
        `;
        contactsTableBody.appendChild(row);
    });
}

// --- ИЗМЕНЕНО: Функция применения фильтра ---
function applyFilter() {
    const filterLastName = filterLastNameInput.value.toLowerCase();
    const filterFirstName = filterFirstNameInput.value.toLowerCase();
    const filterAge = filterAgeInput.value.toLowerCase();
    // Получаем нормализованную строку поиска для телефона
    const normalizedFilterPhone = normalizePhoneNumber(filterPhoneInput.value);

    // Фильтрация
    filteredContacts = contacts.filter(contact => {
        return (
            (!filterLastName || contact.lastName.toLowerCase().includes(filterLastName)) &&
            (!filterFirstName || contact.firstName.toLowerCase().includes(filterFirstName)) &&
            // Фильтр по возрасту как по строке
            (!filterAge || String(contact.age).toLowerCase().includes(filterAge)) &&
            // Фильтр по телефону: ищем нормализованную строку поиска в нормализованном телефоне контакта
            (!normalizedFilterPhone || contact.phone.includes(normalizedFilterPhone))
        );
    });

    renderTable(filteredContacts);
}
// --------------------------------------------

addContactBtn.addEventListener('click', () => {
    addContact(
        lastNameInput.value.trim(),
        firstNameInput.value.trim(),
        ageInput.value.trim(),
        phoneInput.value.trim()
    );
    // Очищаем поля ввода после добавления
    lastNameInput.value = '';
    firstNameInput.value = '';
    ageInput.value = '';
    phoneInput.value = '';
});

randomContactBtn.addEventListener('click', () => {
    if (randomPeople && randomPeople.length > 0) {
        const randomIndex = Math.floor(Math.random() * randomPeople.length);
        const randomPerson = randomPeople[randomIndex];
        // Убедимся, что возраст из randomPeople - это число
        addContact(randomPerson.lastName, randomPerson.firstName, String(randomPerson.age), randomPerson.phone);
    }
});

filterBtn.addEventListener('click', applyFilter);

// Инициализация таблицы
renderTable(contacts);