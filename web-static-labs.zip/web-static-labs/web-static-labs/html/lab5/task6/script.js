const passwordLengthInput = document.getElementById('passwordLength');
const includeLowercaseCheckbox = document.getElementById('includeLowercase');
const includeUppercaseCheckbox = document.getElementById('includeUppercase');
const includeNumbersCheckbox = document.getElementById('includeNumbers');
const includeSymbolsCheckbox = document.getElementById('includeSymbols');
const generateBtn = document.getElementById('generateBtn');
const passwordOutput = document.getElementById('passwordOutput');
const copyBtn = document.getElementById('copyBtn');

const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const numberChars = '0123456789';
const symbolChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';

let currentPassword = '';

function generatePassword() {
    const length = parseInt(passwordLengthInput.value);
    if (isNaN(length) || length < 6 || length > 32) {
        passwordOutput.textContent = 'Некорректная длина';
        copyBtn.disabled = true;
        return;
    }

    let charSet = '';
    let selectedSets = [];

    if (includeLowercaseCheckbox.checked) {
        charSet += lowercaseChars;
        selectedSets.push(lowercaseChars);
    }
    if (includeUppercaseCheckbox.checked) {
        charSet += uppercaseChars;
        selectedSets.push(uppercaseChars);
    }
    if (includeNumbersCheckbox.checked) {
        charSet += numberChars;
        selectedSets.push(numberChars);
    }
    if (includeSymbolsCheckbox.checked) {
        charSet += symbolChars;
        selectedSets.push(symbolChars);
    }

    if (charSet === '') {
        passwordOutput.textContent = 'Выберите хотя бы один тип символов';
        copyBtn.disabled = true;
        return;
    }

    let password = '';

    for (let set of selectedSets) {
        password += set[Math.floor(Math.random() * set.length)];
    }

    for (let i = password.length; i < length; i++) {
        password += charSet[Math.floor(Math.random() * charSet.length)];
    }

    password = password.split('').sort(() => Math.random() - 0.5).join('');

    currentPassword = password;
    passwordOutput.textContent = currentPassword;
    copyBtn.disabled = false;
}

function copyPassword() {
    if (currentPassword) {
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(currentPassword)
                .then(() => {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = 'Скопировано!';
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                    }, 2000);
                })
                .catch(() => {
                    const textarea = document.createElement('textarea');
                    textarea.value = currentPassword;
                    textarea.style.position = 'fixed';
                    textarea.style.opacity = '0';
                    document.body.appendChild(textarea);
                    textarea.select();
                    try {
                        if (document.execCommand('copy')) {
                            const originalText = copyBtn.textContent;
                            copyBtn.textContent = 'Скопировано!';
                            setTimeout(() => {
                                copyBtn.textContent = originalText;
                            }, 2000);
                        } else {
                            console.error('Ошибка копирования: execCommand не сработал');
                        }
                    } catch (e) {
                        console.error('Ошибка копирования: ', e);
                    }
                    document.body.removeChild(textarea);
                });
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = currentPassword;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                if (document.execCommand('copy')) {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = 'Скопировано!';
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                    }, 2000);
                } else {
                    console.error('Ошибка копирования: execCommand не сработал');
                }
            } catch (e) {
                console.error('Ошибка копирования: ', e);
            }
            document.body.removeChild(textarea);
        }
    }
}

generateBtn.addEventListener('click', generatePassword);
copyBtn.addEventListener('click', copyPassword);