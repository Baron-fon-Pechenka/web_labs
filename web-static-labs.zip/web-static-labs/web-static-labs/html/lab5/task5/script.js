const display = document.getElementById('display');

let currentInput = '0';
let operator = null;
let previousInput = '';
let shouldResetDisplay = false;
let waitingForLogBase = false;

function updateDisplay() {
    display.value = currentInput;
}

function appendNumber(number) {
    if (shouldResetDisplay) {
        currentInput = number;
        shouldResetDisplay = false;
    } else if (waitingForLogBase) {
        currentInput = number;
        waitingForLogBase = false;
    } else {
        if (currentInput === '0' && number !== '.') {
            currentInput = number;
        } else {
            currentInput += number;
        }
    }
    updateDisplay();
}

function handleOperator(op) {
    if (op === 'sqrt') {
        if (currentInput === '') return;
        const num = parseFloat(currentInput);
        if (isNaN(num)) {
            display.value = 'Ошибка';
            clearAll();
            return;
        }
        if (num < 0) {
            display.value = 'Нельзя извлечь корень из отрицательного числа';
            clearAll();
            return;
        }
        currentInput = String(Math.sqrt(num));
        updateDisplay();
        return;
    }

    if (op === 'log') {
        if (currentInput === '') return;
        const num = parseFloat(currentInput);
        if (isNaN(num) || num <= 0) {
            display.value = 'Некорректные параметры для логарифма';
            clearAll();
            return;
        }
        previousInput = currentInput;
        waitingForLogBase = true;
        currentInput = '';
        shouldResetDisplay = false;
        operator = op;
        updateDisplay();
        return;
    }

    if (waitingForLogBase) {
        waitingForLogBase = false;
        previousInput = '';
    }

    if (currentInput === '' && operator !== 'sqrt' && operator !== 'log') {
        operator = op;
        return;
    }

    if (operator !== null && !waitingForLogBase) {
        calculate();
    }

    previousInput = currentInput;
    operator = op;
    shouldResetDisplay = true;
}

function calculate() {
    if (operator === null) return;

    let a, b;
    if (operator === 'log') {
        a = parseFloat(previousInput);
        b = parseFloat(currentInput);
    } else {
        a = parseFloat(previousInput);
        b = parseFloat(currentInput);
    }

    if (isNaN(a) || (operator !== 'log' && isNaN(b))) {
        display.value = 'Ошибка';
        clearAll();
        return;
    }

    let res;
    switch (operator) {
        case '+':
            res = a + b;
            break;
        case '-':
            res = a - b;
            break;
        case '*':
            res = a * b;
            break;
        case '/':
            if (b === 0) {
                display.value = 'Деление на ноль';
                clearAll();
                return;
            }
            res = a / b;
            break;
        case 'log':
            if (a <= 0 || b <= 0 || b === 1) {
                display.value = 'Некорректные параметры для логарифма';
                clearAll();
                return;
            }
            res = Math.log(a) / Math.log(b);
            operator = null;
            previousInput = '';
            waitingForLogBase = false;
            break;
        default:
            display.value = 'Неизвестная операция';
            clearAll();
            return;
    }

    currentInput = String(res);
    display.value = currentInput;

    if (operator !== 'log') {
        operator = null;
        previousInput = '';
    }
    shouldResetDisplay = true;
}

function clearAll() {
    currentInput = '0';
    operator = null;
    previousInput = '';
    shouldResetDisplay = false;
    waitingForLogBase = false;
    updateDisplay();
}

document.addEventListener('click', (e) => {
    const target = e.target;

    if (target.classList.contains('calc-button')) {
        const digit = target.dataset.digit;
        const op = target.dataset.op;
        const action = target.dataset.action;

        if (digit) {
            appendNumber(digit);
        } else if (op) {
            if (op === 'sqrt' || op === 'log') {
                handleOperator(op);
            } else {
                handleOperator(op);
            }
        } else if (action === 'calculate') {
            if (waitingForLogBase) {
                if (currentInput === '') return;
                calculate();
            } else if (operator !== null) {
                calculate();
            }
        } else if (action === 'clear') {
            clearAll();
        }
    }
});

// --- Обработка клавиатуры ---
document.addEventListener('keydown', (e) => {
    // Предотвращаем стандартное поведение для клавиш, которые мы обрабатываем
    if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '=', 'Enter', 'Escape', '+', '-', '*', '/'].includes(e.key)) {
        e.preventDefault();
    }

    // Игнорируем модификаторы (Shift, Ctrl, Alt) при обычных клавишах
    if (e.shiftKey || e.ctrlKey || e.altKey) return;

    // Обработка чисел
    if (/[0-9]/.test(e.key)) {
        appendNumber(e.key);
        return;
    }

    // Обработка точки
    if (e.key === '.') {
        appendNumber('.');
        return;
    }

    // Обработка операторов
    if (e.key === '+') {
        handleOperator('+');
        return;
    }
    if (e.key === '-') {
        handleOperator('-');
        return;
    }
    if (e.key === '*') {
        handleOperator('*');
        return;
    }
    if (e.key === '/') {
        handleOperator('/');
        return;
    }
    // Обработка Enter как =
    if (e.key === 'Enter' || e.key === '=') {
        if (waitingForLogBase) {
            if (currentInput === '') return;
            calculate();
        } else if (operator !== null) {
            calculate();
        }
        return;
    }

    // Обработка Escape как C
    if (e.key === 'Escape') {
        clearAll();
        return;
    }
});

updateDisplay();