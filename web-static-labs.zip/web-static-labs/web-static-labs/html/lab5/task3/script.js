const grid = document.getElementById('grid');
const paintBtn = document.getElementById('paintBtn');
const statsBody = document.getElementById('statsBody');

const colors = [
    "#1abc9c", "#2ecc71", "#3498db", "#9b59b6", "#34495e", "#16a085", "#27ae60", "#2980b9", "#8e44ad", "#2c3e50",
    "#f1c40f", "#e67e22", "#e74c3c", "#ecf0f1", "#95a5a6", "#f39c12", "#d35400", "#c0392b", "#bdc3c7", "#7f8c8d"
];

const whiteColor = "#ffffff";
const blackColor = "#000000";

let gridCells = [];
let colorCounts = {};

function initializeGrid() {
    grid.innerHTML = '';
    gridCells = [];
    for (let i = 0; i < 100; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.style.backgroundColor = whiteColor;
        grid.appendChild(cell);
        gridCells.push(cell);
    }
}

function updateStats() {
    statsBody.innerHTML = '';
    const entries = Object.entries(colorCounts).sort((a, b) => b[1] - a[1]);
    entries.forEach(([color, count]) => {
        const row = document.createElement('tr');
        const colorCell = document.createElement('td');
        const countCell = document.createElement('td');

        const colorBlock = document.createElement('span');
        colorBlock.className = 'color-block';
        colorBlock.style.backgroundColor = color;

        colorCell.appendChild(colorBlock);
        colorCell.appendChild(document.createTextNode(color));
        countCell.textContent = count;

        row.appendChild(colorCell);
        row.appendChild(countCell);
        statsBody.appendChild(row);
    });
}

function updateColorCounts() {
    colorCounts = {};
    gridCells.forEach(cell => {
        const color = cell.style.backgroundColor.toLowerCase();
        colorCounts[color] = (colorCounts[color] || 0) + 1;
    });
    updateStats();
}

function paintGrid() {
    gridCells.forEach(cell => {
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        cell.style.backgroundColor = randomColor;
    });
    updateColorCounts();
}

paintBtn.addEventListener('click', paintGrid);

grid.addEventListener('click', (e) => {
    if (e.target.classList.contains('cell')) {
        e.target.style.backgroundColor = whiteColor;
        updateColorCounts();
    }
});

grid.addEventListener('contextmenu', (e) => {
    if (e.target.classList.contains('cell')) {
        e.preventDefault();
        e.target.style.backgroundColor = blackColor;
        updateColorCounts();
    }
});

initializeGrid();
updateColorCounts();