const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const randomTaskBtn = document.getElementById('randomTaskBtn');
const taskList = document.getElementById('taskList');

function getFormattedDateTime() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}

function createTaskElement(text) {
    const item = document.createElement('div');
    item.className = 'task-item';
    item.dataset.taskText = text;

    const header = document.createElement('div');
    header.className = 'task-header';
    header.textContent = getFormattedDateTime();

    const taskText = document.createElement('div');
    taskText.className = 'task-text';
    taskText.textContent = text;

    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'task-buttons';

    const copyBtn = document.createElement('button');
    copyBtn.className = 'task-button';
    copyBtn.textContent = 'Копировать в буфер';

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'task-button delete';
    deleteBtn.textContent = 'Удалить задачу';

    buttonsDiv.appendChild(copyBtn);
    buttonsDiv.appendChild(deleteBtn);

    item.appendChild(header);
    item.appendChild(taskText);
    item.appendChild(buttonsDiv);

    copyBtn.addEventListener('click', () => {
        const taskDiv = copyBtn.closest('.task-item');
        const textToCopy = taskDiv.dataset.taskText;

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = 'Скопировано!';
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                    }, 1000);
                })
                .catch(() => {
                    const textarea = document.createElement('textarea');
                    textarea.value = textToCopy;
                    textarea.style.position = 'fixed';
                    textarea.style.opacity = '0';
                    document.body.appendChild(textarea);
                    textarea.select();
                    try {
                        if (document.execCommand('copy')) {
                            const originalText = copyBtn.textContent;
                            copyBtn.textContent = 'Скопировано!';
                            setTimeout(() => {
                                copyBtn.textContent = originalText;
                            }, 1000);
                        } else {
                            console.error('Ошибка копирования: execCommand не сработал');
                        }
                    } catch (e) {
                        console.error('Ошибка копирования: ', e);
                    }
                    document.body.removeChild(textarea);
                });
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = textToCopy;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                if (document.execCommand('copy')) {
                    const originalText = copyBtn.textContent;
                    copyBtn.textContent = 'Скопировано!';
                    setTimeout(() => {
                        copyBtn.textContent = originalText;
                    }, 1000);
                } else {
                    console.error('Ошибка копирования: execCommand не сработал');
                }
            } catch (e) {
                console.error('Ошибка копирования: ', e);
            }
            document.body.removeChild(textarea);
        }
    });

    deleteBtn.addEventListener('click', () => {
        taskList.removeChild(item);
    });

    return item;
}

addTaskBtn.addEventListener('click', () => {
    const text = taskInput.value.trim();
    if (text) {
        const taskElement = createTaskElement(text);
        taskList.insertBefore(taskElement, taskList.firstChild);
        taskInput.value = '';
    }
});

randomTaskBtn.addEventListener('click', () => {
    if (randomTasks && randomTasks.length > 0) {
        const randomIndex = Math.floor(Math.random() * randomTasks.length);
        const randomTask = randomTasks[randomIndex];
        const taskElement = createTaskElement(randomTask);
        taskList.insertBefore(taskElement, taskList.firstChild);
    }
});

taskInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        addTaskBtn.click();
    }
});