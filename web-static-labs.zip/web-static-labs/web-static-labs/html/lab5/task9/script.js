document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('userForm');
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    const age = document.getElementById('age');
    const city = document.getElementById('city');
    const courierCheckbox = document.getElementById('courierCheckbox');
    const addressGroup = document.getElementById('addressGroup');
    const address = document.getElementById('address');

    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const ageError = document.getElementById('ageError');
    const ageHint = document.getElementById('ageHint');
    const cityError = document.getElementById('cityError');
    const addressError = document.getElementById('addressError');

    courierCheckbox.addEventListener('change', () => {
        if (courierCheckbox.checked) {
            addressGroup.classList.add('visible');
        } else {
            addressGroup.classList.remove('visible');
            address.value = '';
            clearError(addressError);
            setAddressFieldState();
        }
        setAddressFieldState();
    });

    username.addEventListener('input', () => {
        const isValid = validateUsername();
        setFieldState(username, isValid);
    });
    password.addEventListener('input', () => {
        const isValid = validatePassword();
        setFieldState(password, isValid);
        if (confirmPassword.value) {
            const isConfirmValid = validateConfirmPassword();
            setFieldState(confirmPassword, isConfirmValid);
        }
    });
    confirmPassword.addEventListener('input', () => {
        const isValid = validateConfirmPassword();
        setFieldState(confirmPassword, isValid);
    });
    age.addEventListener('input', () => {
        const isValid = validateAge();
        setFieldState(age, isValid);
    });
    city.addEventListener('change', () => {
        const isValid = validateCity();
        setFieldState(city, isValid);
    });
    address.addEventListener('input', () => {
        setAddressFieldState();
        if (courierCheckbox.checked) validateAddress();
    });

    function setFieldState(field, isValid) {
        field.classList.remove('valid-field', 'invalid-field');
        if (field.value.trim() !== '') {
            if (isValid) {
                field.classList.add('valid-field');
            } else {
                field.classList.add('invalid-field');
            }
        }
    }

    function setAddressFieldState() {
        address.classList.remove('valid-field', 'invalid-field');
        if (courierCheckbox.checked && address.value.trim() !== '') {
             const isValid = address.value.trim().length > 0;
             if (isValid) {
                 address.classList.add('valid-field');
             } else {
                 address.classList.add('invalid-field');
             }
        }
    }

    function validateUsername() {
        clearError(usernameError);
        const value = username.value.trim();
        if (!value) {
            showError(usernameError, 'Логин обязателен.');
            return false;
        }
        if (value.length < 5 || value.length > 20) {
            showError(usernameError, 'Логин должен быть от 5 до 20 символов.');
            return false;
        }
        return true;
    }

    function validatePassword() {
        clearError(passwordError);
        const value = password.value;
        if (!value) {
            showError(passwordError, 'Пароль обязателен.');
            return false;
        }
        if (value.length < 5 || value.length > 12) {
            showError(passwordError, 'Пароль должен быть от 5 до 12 символов.');
            return false;
        }
        if (confirmPassword.value) {
            validateConfirmPassword();
            setFieldState(confirmPassword, password.value === confirmPassword.value);
        }
        return true;
    }

    function validateConfirmPassword() {
        clearError(confirmPasswordError);
        const passValue = password.value;
        const confirmValue = confirmPassword.value;
        if (!confirmValue) {
            showError(confirmPasswordError, 'Подтверждение пароля обязательно.');
            return false;
        }
        if (passValue !== confirmValue) {
            showError(confirmPasswordError, 'Пароли не совпадают.');
            return false;
        }
        return true;
    }

    function validateAge() {
        clearError(ageError);
        clearHint(ageHint);
        const value = age.value.trim();
        if (!value) {
            showError(ageError, 'Возраст обязателен.');
            return false;
        }
        const numValue = Number(value);
        if (isNaN(numValue)) {
            showError(ageError, 'Введите корректное число.');
            return false;
        }
        if (numValue < 14) {
            showError(ageError, 'Возраст слишком мал.');
            return false;
        }
        if (numValue > 120) {
            showError(ageError, 'Возраст слишком велик.');
            return false;
        }
        if (numValue >= 14 && numValue < 18) {
            showHint(ageHint, 'Требуется согласие родителей.');
        }
        return true;
    }

    function validateCity() {
        clearError(cityError);
        if (!city.value) {
            showError(cityError, 'Выберите город.');
            return false;
        }
        return true;
    }

    function validateAddress() {
        clearError(addressError);
        if (courierCheckbox.checked) {
            const value = address.value.trim();
            if (!value) {
                showError(addressError, 'Адрес обязателен при выборе доставки.');
                setAddressFieldState();
                return false;
            }
        }
        setAddressFieldState();
        return true;
    }

    function showError(element, message) {
        element.textContent = message;
        element.style.display = 'block';
    }

    function showHint(element, message) {
        element.textContent = message;
        element.style.display = 'block';
    }

    function clearError(element) {
        element.textContent = '';
        element.style.display = 'none';
    }

    function clearHint(element) {
        element.textContent = '';
        element.style.display = 'none';
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const isUsernameValid = validateUsername();
        setFieldState(username, isUsernameValid);

        const isPasswordValid = validatePassword();
        setFieldState(password, isPasswordValid);

        const isConfirmPasswordValid = validateConfirmPassword();
        setFieldState(confirmPassword, isConfirmPasswordValid);

        const isAgeValid = validateAge();
        setFieldState(age, isAgeValid);

        const isCityValid = validateCity();
        setFieldState(city, isCityValid);

        const isAddressValid = validateAddress();

        const allFieldsValid = isUsernameValid && isPasswordValid && isConfirmPasswordValid &&
                               isAgeValid && isCityValid && isAddressValid;

        if (allFieldsValid) {
            alert('Форма успешно отправлена!');
        } else {
            if (!isUsernameValid) username.focus();
            else if (!isPasswordValid) password.focus();
            else if (!isConfirmPasswordValid) confirmPassword.focus();
            else if (!isAgeValid) age.focus();
            else if (!isCityValid) city.focus();
            else if (!isAddressValid) address.focus();
        }
    });
});