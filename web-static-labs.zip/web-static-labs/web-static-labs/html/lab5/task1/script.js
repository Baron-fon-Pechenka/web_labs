const resultDisplay = document.getElementById('resultDisplay');

let modalWindow = null;
let modalTimeoutId = null;

function openModal() {
    if (modalWindow) return;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'modal';

    modal.innerHTML = `
        <div class="modal-content">
            <h3>Подпишитесь на новости сайта</h3>
            <input type="email" id="emailInput" placeholder="Введите ваш e-mail">
            <div id="errorMessage" class="error-message"></div>
        </div>
        <div class="modal-buttons">
            <button id="subscribeBtn" class="modal-button">Подписаться</button>
            <button id="closeBtn" class="modal-button close">Закрыть</button>
        </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    modalWindow = overlay;

    const emailInput = document.getElementById('emailInput');
    const errorMessage = document.getElementById('errorMessage');
    const subscribeBtn = document.getElementById('subscribeBtn');
    const closeBtn = document.getElementById('closeBtn');

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function closeModal() {
        if (modalTimeoutId) {
            clearTimeout(modalTimeoutId);
            modalTimeoutId = null;
        }
        if (modalWindow) {
            document.body.removeChild(modalWindow);
            modalWindow = null;
        }
    }

    subscribeBtn.addEventListener('click', () => {
        const email = emailInput.value.trim();

        if (!email || !validateEmail(email)) {
            errorMessage.textContent = email ? 'Некорректный e-mail' : 'Введите e-mail';
            emailInput.classList.add('error');
            return;
        }

        errorMessage.textContent = '';
        emailInput.classList.remove('error');

        modal.querySelector('.modal-content').innerHTML = `<p>Спасибо за подписку! На Ваш адрес <strong>${email}</strong> будет направлено письмо</p>`;
        modal.querySelector('.modal-buttons').remove();

        resultDisplay.textContent = `Подписка выполнена на ${email}`;

        modalTimeoutId = setTimeout(closeModal, 10000);
    });

    closeBtn.addEventListener('click', closeModal);

    document.addEventListener('keydown', function escHandler(e) {
        if (e.key === 'Escape') {
            closeModal();
            document.removeEventListener('keydown', escHandler);
        }
    });

    emailInput.addEventListener('input', () => {
        if (emailInput.classList.contains('error')) {
            emailInput.classList.remove('error');
            errorMessage.textContent = '';
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(openModal, 7000);
});