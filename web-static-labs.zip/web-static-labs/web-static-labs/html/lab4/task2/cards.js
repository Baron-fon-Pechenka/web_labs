'use strict';

const $ = (id) => document.getElementById(id);

const digitsOnly = (s) => s.replace(/\D+/g, '');

function luhnCheck(cardNumber) {
    const digits = cardNumber.split('').map(Number);
    const len = digits.length;
    let sum = 0;

    for (let i = 0; i < len; i++) {
        let digit = digits[len - 1 - i];

        if ((i + 1) % 2 === 0) {
            digit *= 2;
            if (digit > 9) digit -= 9;
        }

        sum += digit;
    }

    const isValid = sum % 10 === 0;
    console.log(`[Luhn] Число: ${cardNumber}, Сумма: ${sum}, Валидно: ${isValid}`);
    return isValid;
}

function detectBrand(num) {
    const first = num.charAt(0);
    const firstTwo = num.slice(0, 2);
    const firstThree = num.slice(0, 3);
    const firstFour = num.slice(0, 4);
    const firstSix = num.slice(0, 6);

    if (first === '4' && [13, 16, 19].includes(num.length)) return 'visa';

    if (num.length === 16) {
        if (/^5[1-5]/.test(firstTwo)) return 'mc';
        if (parseInt(firstFour) >= 2221 && parseInt(firstFour) <= 2720) return 'mc';
    }

    if (num.length === 16 && parseInt(firstFour) >= 2200 && parseInt(firstFour) <= 2204) return 'mir';

    if ((firstTwo === '34' || firstTwo === '37') && num.length === 15) return 'amex';

    if (num.length === 16 && parseInt(firstFour) >= 3528 && parseInt(firstFour) <= 3589) return 'jcb';

    if (firstTwo === '62' && num.length >= 16 && num.length <= 19) return 'unionpay';

    if (num.length === 16) {
        if (firstFour === '6011') return 'discover';
        if (firstTwo === '65') return 'discover';
        if (parseInt(firstSix) >= 622126 && parseInt(firstSix) <= 622925) return 'discover';
        if (parseInt(firstThree) >= 644 && parseInt(firstThree) <= 649) return 'discover';
    }

    if (firstTwo === '36' && num.length === 14) return 'diners';

    if (firstTwo === '30' && ['0', '1', '2', '3', '4', '5'].includes(num.charAt(2)) && num.length === 14) return 'diners';

    if ((firstTwo === '54' || firstTwo === '55') && num.length === 16) return 'diners';

    if (num.length >= 12 && num.length <= 19) {
        if (firstTwo === '50') return 'maestro';
        if (firstTwo >= '56' && firstTwo <= '58') return 'maestro';
        if (first === '6') return 'maestro';
    }

    if (first === '1' && num.length === 15) return 'uatp';

    return null;
}

function formatCardNumber(num) {
    return num.replace(/(\d{4})/g, '$1 ').trim();
}

function clearHighlight() {
    const active = document.querySelector('.cards-icons img.hl');
    if (active) active.classList.remove('hl');
}

document.addEventListener('DOMContentLoaded', () => {
    const input = $('cardNumber');
    const button = $('cardCheck');
    const out = $('result');

    input.addEventListener('input', () => {
        clearHighlight();
        const clean = digitsOnly(input.value);
        if (clean.length <= 16) {
            input.value = formatCardNumber(clean);
        }
    });

    button.addEventListener('click', () => {
        clearHighlight();
        const raw = String(input.value);
        const num = digitsOnly(raw);

        console.log(`[Input] Raw: "${raw}" → Clean: "${num}"`);

        if (num.length < 12 || num.length > 19) {
            out.textContent = 'Неверная длина номера карты';
            return;
        }

        if (!luhnCheck(num)) {
            out.textContent = 'Номер карты не прошёл проверку по алгоритму Луна';
            return;
        }

        const brandId = detectBrand(num);
        if (brandId) {
            const img = $(brandId);
            if (img) {
                img.classList.add('hl');

                setTimeout(() => {
                    img.classList.remove('hl');
                }, 2000);
            }
            out.textContent = `Карта ${brandId.toUpperCase()} распознана`;
        } else {
            out.textContent = 'Неизвестный тип карты';
        }

        input.value = formatCardNumber(num);
    });

    const brandSelect = $('brandSelect');
    const generateBtn = $('generateBtn');

    function generateValidCardNumber(brand) {
        let prefix;
        let length;

        switch (brand) {
            case 'visa':
                prefix = '4';
                length = 16;
                break;
            case 'mc':
                if (Math.random() > 0.5) {
                    prefix = (Math.floor(Math.random() * 5) + 51).toString();
                } else {
                    prefix = (Math.floor(Math.random() * (2720 - 2221 + 1)) + 2221).toString();
                }
                length = 16;
                break;
            case 'mir':
                prefix = (Math.floor(Math.random() * 5) + 2200).toString();
                length = 16;
                break;
            case 'amex':
                prefix = ['34', '37'][Math.floor(Math.random() * 2)];
                length = 15;
                break;
            case 'jcb':
                prefix = (Math.floor(Math.random() * (3589 - 3528 + 1)) + 3528).toString();
                length = 16;
                break;
            case 'unionpay':
                prefix = '62';
                length = 16;
                break;
            case 'discover':
                const choices = [
                    () => '6011',
                    () => (Math.floor(Math.random() * (622925 - 622126 + 1)) + 622126).toString(),
                    () => (Math.floor(Math.random() * (649 - 644 + 1)) + 644).toString(),
                    () => '65'
                ];
                prefix = choices[Math.floor(Math.random() * choices.length)]();
                length = 16;
                break;
            case 'diners':
                const dinersChoices = [
                    () => '36',
                    () => '30' + (Math.floor(Math.random() * 6)).toString(),
                    () => ['54', '55'][Math.floor(Math.random() * 2)]
                ];
                prefix = dinersChoices[Math.floor(Math.random() * dinersChoices.length)]();
                length = 14;
                break;
            case 'maestro':
                const maestroChoices = [
                    () => '50',
                    () => (Math.floor(Math.random() * 3) + 56).toString(),
                    () => '6'
                ];
                prefix = maestroChoices[Math.floor(Math.random() * maestroChoices.length)]();
                length = 16;
                break;
            case 'uatp':
                prefix = '1';
                length = 15;
                break;
            default:
                return null;
        }

        let attempts = 0;
        const maxAttempts = 10000;

        while (attempts < maxAttempts) {
            let num = prefix;
            while (num.length < length - 1) {
                num += Math.floor(Math.random() * 10).toString();
            }

            let sum = 0;
            let isEven = false;

            for (let i = num.length - 1; i >= 0; i--) {
                let digit = parseInt(num[i], 10);

                if (isEven) {
                    digit *= 2;
                    if (digit > 9) digit -= 9;
                }

                sum += digit;
                isEven = !isEven;
            }

            const checkDigit = (10 - (sum % 10)) % 10;
            num += checkDigit;

            if (luhnCheck(num) && detectBrand(num) === brand) {
                console.log(`[Генерация] Номер ${num} валиден для ${brand}`);
                return num;
            }

            attempts++;
        }

        console.error(`[Генерация] Не удалось сгенерировать валидный номер для ${brand} за ${maxAttempts} попыток`);
        return null;
    }

    generateBtn.addEventListener('click', () => {
        const selectedBrand = brandSelect.value;
        const validNumber = generateValidCardNumber(selectedBrand);

        if (validNumber) {
            input.value = formatCardNumber(validNumber);
            clearHighlight();
            out.textContent = `Сгенерирован валидный номер ${selectedBrand.toUpperCase()}`;
        } else {
            out.textContent = 'Ошибка генерации — попробуйте снова';
        }
    });
});