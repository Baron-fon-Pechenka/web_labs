'use strict';

// Утилита короткого доступа по id
const $ = (id) => document.getElementById(id);

// Чтение числа из input: пустая строка -> NaN
const readNumber = (el) => {
    const raw = String(el.value).trim(); // убираем пробелы в конце и начале
    return raw === '' ? NaN : Number(raw);
};

// функция вычисления результата
function calc(a, op, b, base = 10) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return b === 0 ? NaN : a / b;
        case 'sqrt': return a < 0 ? NaN : Math.sqrt(a);
        case 'log':
            if (a <= 0 || base <= 0 || base === 1) return NaN;
            return Math.log(a) / Math.log(base);
        default: return NaN;
    }
}

// Обновление состояния полей в зависимости от выбранной операции
function updateInputFields() {
    const operator = $('operator').value;
    const operand2 = $('operand2');
    const baseRow = $('baseRow');
    const logBase = $('logBase');

    if (operator === 'sqrt' || operator === 'log') {
        operand2.disabled = true;
        operand2.style.display = 'none';
        baseRow.classList.toggle('active', operator === 'log');
        if (operator === 'log') {
            logBase.disabled = false;
            logBase.style.display = 'block';
        } else {
            logBase.disabled = true;
            logBase.style.display = 'none';
            logBase.value = '';
        }
    } else {
        operand2.disabled = false;
        operand2.style.display = 'block';
        baseRow.classList.remove('active');
        logBase.disabled = true;
        logBase.style.display = 'none';
        logBase.value = '';
    }
}

// ждем полной загрузки DOM
document.addEventListener('DOMContentLoaded', () => {
    const operator = $('operator');
    const operand1 = $('operand1');
    const operand2 = $('operand2');
    const logBase = $('logBase');
    const doCalc = $('doCalc');
    const resultEl = $('result');
    const roundCheckbox = $('roundCheckbox');

    // Обработчик изменения оператора
    operator.addEventListener('change', updateInputFields);

    // Инициализация состояния полей
    updateInputFields();

    // обработчик клика по кнопке "="
    doCalc.addEventListener('click', () => {
        const a = readNumber(operand1);
        const b = readNumber(operand2);
        const base = readNumber(logBase);
        const op = operator.value;
        const shouldRound = roundCheckbox.checked;

        if (Number.isNaN(a)) {
            resultEl.textContent = 'Введите первый операнд';
            return;
        }

        if ((op === '+' || op === '-' || op === '*' || op === '/') && Number.isNaN(b)) {
            resultEl.textContent = 'Введите второй операнд';
            return;
        }

        if (op === '/' && b === 0) {
            resultEl.textContent = 'Деление на ноль невозможно';
            return;
        }

        if (op === 'log' && Number.isNaN(base)) {
            resultEl.textContent = 'Введите основание логарифма';
            return;
        }

        const res = calc(a, op, b, base);
        if (Number.isNaN(res)) {
            if (op === 'sqrt' && a < 0) {
                resultEl.textContent = 'Нельзя извлечь корень из отрицательного числа';
            } else if (op === 'log' && (a <= 0 || base <= 0 || base === 1)) {
                resultEl.textContent = 'Некорректные параметры для логарифма';
            } else {
                resultEl.textContent = 'Не удалось вычислить';
            }
            return;
        }

        resultEl.textContent = shouldRound ? res.toFixed(3) : String(res);
    });
});

// Эффект параллакса
document.addEventListener('mousemove', (e) => {
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    document.body.style.backgroundPosition = `${x * 100}% ${y * 100}%`;
});