const passwordInput = document.getElementById('passwordInput');
const validateBtn = document.getElementById('validateBtn');
const resultDetails = document.querySelector('.result-details');

const specialChars = new Set('~!#$%^&*()_-+=?/,.[]{}<>|\\');

function analyzePassword(password) {
    const length = password.length;
    let score = 0;
    let reasons = [];

    if (length < 5) {
        return { score: 0, reasons: ['1'] };
    }

    if (length >= 5 && length <= 9) {
        score += 1;
        reasons.push('2');
    }
    else if (length >= 10 && length <= 12) {
        score += 2;
        reasons.push('3');
    }
    else if (length > 12) {
        score += 3;
        reasons.push('4');
    }

    let hasLower = false;
    let hasUpper = false;
    let hasDigit = false;
    let hasSpecial = false;

    for (let char of password) {
        if (char >= 'a' && char <= 'z') hasLower = true;
        else if (char >= 'A' && char <= 'Z') hasUpper = true;
        else if (char >= '0' && char <= '9') hasDigit = true;
        else if (specialChars.has(char)) hasSpecial = true;
    }

    const types = [hasLower, hasUpper, hasDigit, hasSpecial].filter(Boolean).length;
    const additionalTypes = Math.min(2, types - 1);
    if (additionalTypes > 0) {
        score += additionalTypes;
        reasons.push(`5(${additionalTypes})`);
    }

    if (hasLower && hasUpper) {
        score += 1;
        reasons.push('6');
    }

    let specialCount = 0;
    for (let char of password) {
        if (specialChars.has(char)) specialCount++;
    }
    if (specialCount > length * 0.3) {
        score += 2;
        reasons.push('7');
    }

    let hasConsecutive = false;
    let currentType = null;
    let currentLength = 0;

    for (let i = 0; i < password.length; i++) {
        const char = password[i];
        let type = null;
        if (char >= '0' && char <= '9') type = 'digit';
        else if ((char >= 'a' && char <= 'z') || (char >= 'A' && char <= 'Z')) type = 'letter';
        else type = 'special';

        if (type === 'digit' || type === 'letter') {
            if (type === currentType) {
                currentLength++;
            } else {
                if (currentType && currentLength >= 3) {
                    hasConsecutive = true;
                }
                currentType = type;
                currentLength = 1;
            }
        } else {
            if (currentType && currentLength >= 3) {
                hasConsecutive = true;
            }
            currentType = null;
            currentLength = 0;
        }
    }
    if (currentType && currentLength >= 3) {
        hasConsecutive = true;
    }

    if (!hasConsecutive) {
        score += 2;
        reasons.push('8');
    }

    score = Math.min(10, score);

    return { score, reasons };
}

validateBtn.addEventListener('click', () => {
    const password = passwordInput.value;
    const { score, reasons } = analyzePassword(password);

    let output = `<p>Оценка: <strong>${score}</strong> баллов</p>`;
    output += `<p>Подошедшие критерии: <strong>${reasons.join(', ')}</strong></p>`;
    output += `<p>Пароль: <strong>${password}</strong></p>`;

    resultDetails.innerHTML = output;
});

passwordInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        validateBtn.click();
    }
});