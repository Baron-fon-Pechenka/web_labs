const dateInput = document.getElementById('dateInput');
const validateBtn = document.getElementById('validateBtn');
const result = document.getElementById('result');

const dateRegex = /^(\d{2})-(\d{2})-(\d{4})\s(\d{2}):(\d{2}):(\d{2})$/;

function isValidDate(day, month, year, hour, minute, second) {
    if (month < 1 || month > 12) return false;
    if (day < 1) return false;
    if (hour < 0 || hour > 23) return false;
    if (minute < 0 || minute > 59) return false;
    if (second < 0 || second > 59) return false;

    const date = new Date(year, month - 1, day, hour, minute, second);

    return date.getDate() === day &&
           date.getMonth() === month - 1 &&
           date.getFullYear() === year &&
           date.getHours() === hour &&
           date.getMinutes() === minute &&
           date.getSeconds() === second;
}

function validateDateTime(str) {
    const match = str.match(dateRegex);

    if (!match) {
        return "Формат некорректен, данные не проверяются";
    }

    const [, day, month, year, hour, minute, second] = match.map(Number);

    if (isValidDate(day, month, year, hour, minute, second)) {
        return "Формат корректен, данные корректны";
    } else {
        return "Формат корректен, данные некорректны";
    }
}

validateBtn.addEventListener('click', () => {
    const input = dateInput.value.trim();
    const output = validateDateTime(input);
    result.textContent = output;
});

dateInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        validateBtn.click();
    }
});