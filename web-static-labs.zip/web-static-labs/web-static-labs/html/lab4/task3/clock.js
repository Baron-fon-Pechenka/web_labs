function updateDigitalTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    document.getElementById('time').textContent = `${hours}:${minutes}:${seconds}`;
}

function initClock() {
    const now = new Date();

    const secondsDeg = (now.getSeconds() / 60) * 360 - 90;
    const minutesDeg = (now.getMinutes() / 60) * 360 + (now.getSeconds() / 60) * 6 - 90;
    const hoursDeg = ((now.getHours() % 12) / 12) * 360 + (now.getMinutes() / 60) * 30 - 90;


    const style = document.createElement('style');
    style.innerHTML = `
        @keyframes clock-hand-rotate--hour {
            from { transform: rotate(${hoursDeg}deg); }
            to { transform: rotate(${hoursDeg + 360}deg); }
        }
        @keyframes clock-hand-rotate--minute {
            from { transform: rotate(${minutesDeg}deg); }
            to { transform: rotate(${minutesDeg + 360}deg); }
        }
        @keyframes clock-hand-rotate--second {
            from { transform: rotate(${secondsDeg}deg); }
            to { transform: rotate(${secondsDeg + 360}deg); }
        }
        #hour-hand {
            animation: clock-hand-rotate--hour 43200s linear infinite;
        }
        #minute-hand {
            animation: clock-hand-rotate--minute 3600s linear infinite;
        }
        #second-hand {
            animation: clock-hand-rotate--second 60s linear infinite;
        }
    `;

    document.head.appendChild(style);
}

setInterval(updateDigitalTime, 1000);
updateDigitalTime(); 
initClock();