const timezones = {
    'Europe/Moscow': { offset: 3, name: 'Москва' },
    'Asia/Tokyo': { offset: 9, name: 'Токио' },
    'Europe/London': { offset: 0, name: 'Лондон' },
    'America/New_York': { offset: -5, name: 'Нью-Йорк' },
    'America/Sietle': { offset: -8, name: 'Сиэтл' }
};

const timezoneSelect = document.getElementById('timezoneSelect');
const timeDisplay = document.getElementById('time');
const clockContainer = document.getElementById('clockContainer');

let currentSelectedTimezone = timezoneSelect.value;

// Функция получения времени в часовом поясе
function getTimeInTimezone(timezone) {
    const now = new Date();
    const options = {
        timeZone: timezone,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };
    const timeString = now.toLocaleTimeString('ru-RU', options);
    const [hour, minute, second] = timeString.split(':').map(Number);

    return { hour, minute, second, timeString };
}

// Функция получения градиента по часу
function getBackgroundByHour(hour) {
    let hue;
    if (hour < 6) {
        hue = 240 + (hour / 6) * 60;
    } else if (hour < 12) {
        hue = 300 + ((hour - 6) / 6) * (-240);
    } else if (hour < 18) {
        hue = 60 + ((hour - 12) / 6) * 60;
    } else {
        hue = 120 + ((hour - 18) / 6) * 120;
    }

    hue = (hue + 360) % 360;

    const saturation = 50;
    const lightness = 15 + (Math.abs(hour - 12) / 12) * 20;

    return `linear-gradient(135deg, hsl(${hue}, ${saturation}%, ${lightness}%), hsl(${(hue + 30) % 360}, ${saturation}%, ${lightness + 10}%))`;
}

function setAllAnimations() {
    const { hour, minute, second } = getTimeInTimezone(currentSelectedTimezone);


    const secondsDeg = (second / 60) * 360 - 90;
    const minutesDeg = (minute / 60) * 360 + (second / 60) * 6 - 90;
    const hoursDeg = ((hour % 12) / 12) * 360 + (minute / 60) * 30 - 90;


    const style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = `
        @keyframes clock-hand-rotate--hour {
            from { transform: rotate(${hoursDeg}deg); }
            to { transform: rotate(${hoursDeg + 360}deg); }
        }
        @keyframes clock-hand-rotate--minute {
            from { transform: rotate(${minutesDeg}deg); }
            to { transform: rotate(${minutesDeg + 360}deg); }
        }
        @keyframes clock-hand-rotate--second {
            from { transform: rotate(${secondsDeg}deg); }
            to { transform: rotate(${secondsDeg + 360}deg); }
        }
        #hour-hand {
            animation: clock-hand-rotate--hour 43200s linear infinite;
        }
        #minute-hand {
            animation: clock-hand-rotate--minute 3600s linear infinite;
        }
        #second-hand {
            animation: clock-hand-rotate--second 60s linear infinite;
        }
    `;

    const oldStyle = document.getElementById('all-animations');
    if (oldStyle) oldStyle.remove();

    style.id = 'all-animations';
    document.head.appendChild(style);
}

// Функция обновления часовой стрелки (только при смене пояса)
function updateHourHand() {
    const { hour, minute, second } = getTimeInTimezone(currentSelectedTimezone);

    const hoursDeg = ((hour % 12) / 12) * 360 + (minute / 60) * 30 - 90;

    const style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = `
        @keyframes clock-hand-rotate--hour {
            from { transform: rotate(${hoursDeg}deg); }
            to { transform: rotate(${hoursDeg + 360}deg); }
        }
        #hour-hand {
            animation: clock-hand-rotate--hour 43200s linear infinite;
        }
    `;

    const oldStyle = document.getElementById('hour-animation');
    if (oldStyle) oldStyle.remove();

    style.id = 'hour-animation';
    document.head.appendChild(style);
}

function updateDigitalAndBackground() {
    const { hour, timeString } = getTimeInTimezone(currentSelectedTimezone);
    const background = getBackgroundByHour(hour);

    timeDisplay.textContent = timeString;
    clockContainer.style.background = background;
}

setAllAnimations();

updateDigitalAndBackground();

setInterval(updateDigitalAndBackground, 1000);

timezoneSelect.addEventListener('change', () => {
    currentSelectedTimezone = timezoneSelect.value;
    updateHourHand();
    updateDigitalAndBackground();
});