const siteData = {
    
    labsProgress: {
        completed: 2,  // количество сданных работ
        total: 12,     // общее количество работ
        lastUpdated: "19.09.2025"  // дата обновления
    },
    
    // Баллы на Hackerrank
    hackerrankScores: {
        python: 585,  // баллы по Python
        sql: 1130,    // баллы по SQL
        lastUpdated: "19.09.2025"  // дата обновления баллов
    },
    
    // Личная информация
    personalInfo: {
        fullName: "Лещенко Андрей Николаевич",
        group: "ИТ2203",
        email: "a@mz-kk.ru",
        tildaLink: "https://project14735346.tilda.ws/"
    },
    
    // Общая информация о сайте
    siteInfo: {
        lastUpdated: "19.09.2025" 
    }
};

// Функция для форматирования чисел с разделителями тысяч
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { siteData, formatNumber };
}